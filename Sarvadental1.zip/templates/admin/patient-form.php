<?php
$patient = $patient ?? [];
$id = (int) ($patient['id'] ?? 0);
?>
<div class="admin-card">
    <h2 style="margin:0 0 16px;font-size:1.1rem;color:#031D4F;"><?= $id ? 'ویرایش بیمار' : 'افزودن بیمار' ?></h2>
    <form method="post" action="<?= url('/admin/patients/save') ?>" class="row g-3">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= $id ?>">
        <div class="col-md-4">
            <label class="form-label">نام *</label>
            <input name="first_name" class="form-control" required value="<?= e($patient['first_name'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">نام خانوادگی *</label>
            <input name="last_name" class="form-control" required value="<?= e($patient['last_name'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">نام پدر</label>
            <input name="father_name" class="form-control" value="<?= e($patient['father_name'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">موبایل<?= $id ? '' : ' *' ?></label>
            <input name="mobile" class="form-control" <?= $id ? '' : 'required' ?> dir="ltr" value="<?= e($patient['mobile'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">تلفن ثابت</label>
            <input name="landline" class="form-control" dir="ltr" value="<?= e($patient['landline'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">موبایل دوم</label>
            <input name="secondary_mobile" class="form-control" dir="ltr" value="<?= e($patient['secondary_mobile'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">شماره پرونده</label>
            <input name="file_number" class="form-control" value="<?= e($patient['file_number'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">کد ملی</label>
            <input name="national_id" class="form-control" value="<?= e($patient['national_id'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">ایمیل</label>
            <input type="email" name="email" class="form-control" value="<?= e($patient['email'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">تاریخ تولد</label>
            <input type="text" name="birth_date" class="form-control" data-jalali="date" placeholder="مثلاً ۱۳۷۰/۰۱/۱۵" value="<?= e($patient['birth_date'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">سال تولد شمسی</label>
            <input name="birth_year_jalali" class="form-control" dir="ltr" value="<?= e($patient['birth_year_jalali'] ?? '') ?>" placeholder="مثلاً ۱۳۴۹">
        </div>
        <div class="col-md-4">
            <label class="form-label">جنسیت</label>
            <select name="gender" class="form-select">
                <option value="">—</option>
                <option value="female" <?= ($patient['gender'] ?? '') === 'female' ? 'selected' : '' ?>>زن</option>
                <option value="male" <?= ($patient['gender'] ?? '') === 'male' ? 'selected' : '' ?>>مرد</option>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">معرف</label>
            <input name="referrer" class="form-control" value="<?= e($patient['referrer'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label">پزشک مرتبط</label>
            <select name="preferred_doctor_id" class="form-select">
                <option value="">—</option>
                <?php foreach (($doctors ?? []) as $d): ?>
                <option value="<?= (int) $d['id'] ?>" <?= (int) ($patient['preferred_doctor_id'] ?? 0) === (int) $d['id'] ? 'selected' : '' ?>><?= e(trim($d['first_name'] . ' ' . $d['last_name'])) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12">
            <label class="form-label">آدرس</label>
            <input name="address" class="form-control" value="<?= e($patient['address'] ?? '') ?>">
        </div>
        <div class="col-md-6">
            <label class="form-label">نام تماس اضطراری</label>
            <input name="emergency_contact_name" class="form-control" value="<?= e($patient['emergency_contact_name'] ?? '') ?>">
        </div>
        <div class="col-md-6">
            <label class="form-label">موبایل اضطراری</label>
            <input name="emergency_contact_mobile" class="form-control" dir="ltr" value="<?= e($patient['emergency_contact_mobile'] ?? '') ?>">
        </div>
        <div class="col-12">
            <label class="form-label">یادداشت داخلی</label>
            <textarea name="notes" class="form-control" rows="3"><?= e($patient['notes'] ?? '') ?></textarea>
        </div>
        <div class="col-12 d-flex gap-2">
            <button class="btn btn-primary" style="background:#031D4F;border-color:#031D4F;">ذخیره</button>
            <a href="<?= url($id ? '/admin/patients/' . $id : '/admin/patients') ?>" class="btn btn-outline-secondary">بازگشت</a>
        </div>
    </form>
</div>
