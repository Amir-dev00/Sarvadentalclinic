<?php
$items = $items ?? [];
$previews = $previews ?? [];
?>
<div class="admin-card">
    <h2 style="font-size:1.1rem;color:#031D4F;">قانون پیامک خودکار</h2>
    <form method="post" action="<?= url('/admin/sms/automation/save') ?>" class="row g-3">
        <?= csrf_field() ?>
        <input type="hidden" name="id" id="rule_id" value="0">
        <div class="col-md-4"><label class="form-label">نام</label><input name="name" id="rule_name" class="form-control" required placeholder="یادآوری نوبت یک روز قبل"></div>
        <div class="col-md-2"><label class="form-label">مقدار</label><input type="number" min="1" name="offset_value" id="rule_off" class="form-control" value="1"></div>
        <div class="col-md-2">
            <label class="form-label">واحد</label>
            <select name="offset_unit" id="rule_unit" class="form-select"><option value="days">روز قبل</option><option value="hours">ساعت قبل</option></select>
        </div>
        <div class="col-md-2"><label class="form-label">ساعت ارسال</label><input type="time" name="send_time" id="rule_time" class="form-control" value="18:00"></div>
        <div class="col-md-4">
            <label class="form-label">قالب</label>
            <select name="template_id" id="rule_tpl" class="form-select" required>
                <?php foreach (($templates ?? []) as $t): ?><option value="<?= (int) $t['id'] ?>"><?= e($t['name']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label">پزشک (اختیاری)</label>
            <select name="doctor_id" id="rule_doc" class="form-select"><option value="">همه</option>
            <?php foreach (($doctors ?? []) as $d): ?><option value="<?= (int) $d['id'] ?>"><?= e(trim($d['first_name'].' '.$d['last_name'])) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label">خدمت (اختیاری)</label>
            <select name="service_id" id="rule_svc" class="form-select"><option value="">همه</option>
            <?php foreach (($services ?? []) as $s): ?><option value="<?= (int) $s['id'] ?>"><?= e($s['name']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3"><label class="form-label">وضعیت نوبت</label><input name="appointment_statuses" id="rule_st" class="form-control" value="confirmed"></div>
        <div class="col-md-2 d-flex align-items-end"><label class="form-check"><input type="checkbox" name="is_active" id="rule_on" class="form-check-input" checked> فعال</label></div>
        <div class="col-12"><button class="btn btn-primary" style="background:#031D4F;border-color:#031D4F;">ذخیره قانون</button></div>
    </form>
</div>
<div class="admin-card">
    <table class="admin-table">
        <thead><tr><th>قانون</th><th>زمان</th><th>پیش‌نمایش</th><th>وضعیت</th><th></th></tr></thead>
        <tbody>
        <?php if (empty($items)): ?><tr><td colspan="5">قانونی تعریف نشده.</td></tr>
        <?php else: foreach ($items as $item): $pv = $previews[(int) $item['id']] ?? []; ?>
            <tr>
                <td><?= e($item['name']) ?><br><small><?= e($item['template_name']) ?></small></td>
                <td><?= (int) $item['offset_value'] ?> <?= $item['offset_unit'] === 'hours' ? 'ساعت' : 'روز' ?> قبل
                    <?php if ($item['send_time']): ?> · ساعت <?= e(substr((string) $item['send_time'], 0, 5)) ?><?php endif; ?></td>
                <td>
                    <small>نمونه نوبت: <?= e($pv['appointment_at'] ?? '') ?><br>ارسال: <?= e($pv['send_at'] ?? '') ?></small>
                    <pre class="sms-preview"><?= e($pv['preview'] ?? '') ?></pre>
                </td>
                <td><?= !empty($item['is_active']) ? 'فعال' : 'غیرفعال' ?></td>
                <td>
                    <form method="post" action="<?= url('/admin/sms/automation/toggle') ?>"><?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                        <button class="btn btn-sm <?= !empty($item['is_active']) ? 'btn-outline-warning' : 'btn-outline-success' ?>"><?= !empty($item['is_active']) ? 'خاموش' : 'فعال' ?></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>
