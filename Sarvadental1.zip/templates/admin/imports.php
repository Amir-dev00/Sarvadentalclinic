<?php
$items = $items ?? [];
$statusLabels = [
    'uploaded' => 'بارگذاری شده',
    'previewed' => 'پیش‌نمایش',
    'completed' => 'تکمیل شده',
    'failed' => 'ناموفق',
];
?>
<div class="admin-card">
    <h2 style="margin:0 0 16px;font-size:1.1rem;color:#031D4F;">بارگذاری فایل اکسل</h2>
    <p style="color:#6b7280;margin-bottom:16px;">فرمت‌های مجاز: XLSX، XLS، CSV</p>
    <form method="post" action="<?= url('/admin/imports/upload') ?>" enctype="multipart/form-data" class="row g-3 align-items-end">
        <?= csrf_field() ?>
        <div class="col-md-6">
            <label class="form-label">فایل</label>
            <input type="file" name="excel" class="form-control" accept=".xlsx,.xls,.csv" required>
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-primary" style="background:#05B18B;border-color:#05B18B;">آپلود</button>
        </div>
    </form>
</div>

<div class="admin-card">
    <h2 style="margin:0 0 16px;font-size:1.1rem;color:#031D4F;">تاریخچه ورودها</h2>
    <div style="overflow-x:auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>فایل</th>
                    <th>وضعیت</th>
                    <th>کل ردیف</th>
                    <th>وارد شده</th>
                    <th>به‌روز</th>
                    <th>تکراری</th>
                    <th>رد شده</th>
                    <th>تاریخ</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($items)): ?>
                    <tr><td colspan="10">واردسازی ثبت نشده است.</td></tr>
                <?php else: foreach ($items as $item): ?>
                    <tr>
                        <td><?= (int) $item['id'] ?></td>
                        <td><code><?= e($item['filename'] ?? '') ?></code></td>
                        <td><?= e($statusLabels[$item['status'] ?? ''] ?? ($item['status'] ?? '')) ?></td>
                        <td><?= (int) ($item['total_rows'] ?? 0) ?></td>
                        <td><?= (int) ($item['imported_rows'] ?? 0) ?></td>
                        <td><?= (int) ($item['updated_rows'] ?? 0) ?></td>
                        <td><?= (int) ($item['duplicate_rows'] ?? 0) ?></td>
                        <td><?= (int) ($item['skipped_rows'] ?? 0) + (int) ($item['invalid_rows'] ?? 0) ?></td>
                        <td><?= e(to_jalali($item['created_at'] ?? null)) ?></td>
                        <td><a href="<?= url('/admin/imports/' . (int) $item['id']) ?>">مشاهده</a></td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
