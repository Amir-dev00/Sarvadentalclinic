<?php
/** @var array $import */
/** @var array $inspect */
$sheets = $inspect['sheets'] ?? [];
$previewReport = $_SESSION['_import_preview'] ?? null;
unset($_SESSION['_import_preview']);
$conflicts = $conflicts ?? [];
$previous = $inspect['previous_imports'] ?? [];
$fields = [
    'file_number' => 'شماره پرونده',
    'first_name' => 'نام',
    'last_name' => 'نام خانوادگی',
    'father_name' => 'نام پدر',
    'birth_year_jalali' => 'سال تولد (شمسی)',
    'mobile' => 'تلفن همراه',
    'landline' => 'تلفن ثابت',
    'referrer' => 'معرف',
    'national_id' => 'کد ملی',
    'gender' => 'جنسیت',
    'email' => 'ایمیل',
    'address' => 'آدرس',
];
$patientSheetIndex = 0;
foreach ($sheets as $i => $s) {
    if (!empty($s['is_patient_sheet'])) {
        $patientSheetIndex = (int) ($s['index'] ?? $i);
        break;
    }
}
$active = $sheets[$patientSheetIndex] ?? ($sheets[0] ?? []);
$guess = $active['guess'] ?? [];
if (!empty($active['is_patient_sheet'])) {
    $guess = array_merge([
        'file_number' => 'A', 'first_name' => 'B', 'last_name' => 'C', 'father_name' => 'D',
        'birth_year_jalali' => 'E', 'mobile' => 'F', 'landline' => 'G', 'referrer' => 'H',
    ], $guess);
}
$letters = $active['letters'] ?? array_keys($active['columns'] ?? []);
?>
<div class="admin-card">
    <h2 style="margin:0 0 8px;color:#031D4F;">ورود اطلاعات از Excel</h2>
    <p style="color:#6b7280;margin:0;">
        فایل: <code><?= e($import['original_name'] ?? $import['filename'] ?? '') ?></code>
        <?php if (!empty($import['file_hash'])): ?>
            · hash: <code><?= e(substr((string) $import['file_hash'], 0, 12)) ?>…</code>
        <?php endif; ?>
        · وضعیت: <?= e($import['status'] ?? '') ?>
    </p>
</div>

<?php if ($previous): ?>
<div class="admin-card" style="border-color:#f59e0b;">
    <h3 style="margin:0 0 8px;color:#9a3412;">این فایل قبلاً وارد شده است</h3>
    <p style="color:#6b7280;">همان hash قبلاً ثبت شده. می‌توانید ادامه دهید؛ سیستم همچنان ردیف‌به‌ردیف تکراری‌ها را رد می‌کند.</p>
    <ul>
        <?php foreach ($previous as $p): ?>
            <li>#<?= (int) $p['id'] ?> — <?= e(to_jalali($p['created_at'] ?? null)) ?> —
                جدید <?= (int) ($p['imported_rows'] ?? 0) ?> /
                موجود <?= (int) ($p['duplicate_rows'] ?? 0) ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<?php if (!($inspect['ok'] ?? false)): ?>
<div class="admin-card"><p class="auth-alert error">امکان خواندن فایل وجود ندارد.</p></div>
<?php else: ?>

<div class="admin-card">
    <h3 style="color:#031D4F;">برگه‌های فایل</h3>
    <?php foreach ($sheets as $sheet): ?>
        <p>
            <strong><?= e($sheet['title']) ?></strong>
            — <?= (int) ($sheet['row_count'] ?? 0) ?> ردیف
            <?= !empty($sheet['is_patient_sheet']) ? '· <span class="admin-badge admin-badge--ok">برگه بیماران</span>' : '' ?>
        </p>
    <?php endforeach; ?>
    <div style="overflow:auto;max-height:280px;">
        <table class="admin-table">
            <thead>
                <tr>
                    <?php foreach (($active['columns'] ?? []) as $letter => $col): ?>
                        <th><?= e((string) $letter) ?> · <?= e((string) $col) ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach (($active['sample'] ?? []) as $row): ?>
                    <tr>
                        <?php foreach ($row as $cell): ?>
                            <td><?= e((string) $cell) ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<form method="post" action="<?= url('/admin/imports/' . (int) $import['id'] . '/run') ?>" class="admin-card">
    <?= csrf_field() ?>
    <h3 style="color:#031D4F;">تنظیمات واردسازی</h3>
    <div class="row g-3">
        <div class="col-md-3">
            <label class="form-label">برگه بیماران</label>
            <select name="sheet_index" class="form-select">
                <?php foreach ($sheets as $i => $sheet): ?>
                    <option value="<?= (int) ($sheet['index'] ?? $i) ?>" <?= ($patientSheetIndex === (int) ($sheet['index'] ?? $i)) ? 'selected' : '' ?>>
                        <?= e($sheet['title']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-5">
            <label class="form-label">حالت واردسازی</label>
            <select name="import_mode" class="form-select">
                <option value="add_new" selected>فقط افزودن بیماران جدید (پیشنهادی و امن)</option>
                <option value="review_changes">افزودن جدیدها + ثبت تفاوت‌ها برای بررسی</option>
                <?php if (\Sarva\Core\Auth::adminHasPermission('patients.manage')): ?>
                <option value="update_existing">پیشرفته: به‌روزرسانی بیماران موجود (خطرناک)</option>
                <?php endif; ?>
            </select>
            <small class="text-muted">پیش‌فرض هرگز پرونده‌های موجود را بازنویسی نمی‌کند.</small>
        </div>
        <div class="col-md-4 d-flex align-items-end">
            <label class="form-check">
                <input type="checkbox" name="use_sarva_mapping" value="1" class="form-check-input" checked>
                استفاده از نگاشت استاندارد سروا (برگه پرونده)
            </label>
        </div>
        <?php foreach ($fields as $field => $label): ?>
        <div class="col-md-3">
            <label class="form-label"><?= e($label) ?></label>
            <select name="map_<?= e($field) ?>" class="form-select">
                <option value="">—</option>
                <?php foreach ($letters as $letter): ?>
                    <?php $letter = (string) $letter; ?>
                    <option value="<?= e($letter) ?>" <?= ($guess[$field] ?? '') === $letter ? 'selected' : '' ?>>
                        <?= e($letter) ?> — <?= e((string) (($active['columns'][$letter] ?? $letter))) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endforeach; ?>
        <div class="col-12">
            <label class="form-check">
                <input type="checkbox" name="import_radiography" value="1" class="form-check-input">
                پس از واردسازی بیماران، ایندکس رادیوگرافی را هم به‌عنوان مدرک ثبت کن (لینک با نام یکتا)
            </label>
        </div>
        <div class="col-12">
            <label class="form-check">
                <input type="checkbox" name="confirm_import" value="1" class="form-check-input" required>
                تأیید می‌کنم که حالت انتخاب‌شده را فهمیده‌ام و می‌خواهم واردسازی انجام شود
            </label>
        </div>
    </div>
    <div class="d-flex gap-2 mt-3 flex-wrap">
        <button class="btn btn-outline-primary" type="submit" name="preview_only" value="1" formnovalidate>پیش‌نمایش نتیجه (بدون ذخیره)</button>
        <button class="btn" type="submit" style="background:#05B18B;color:#fff;border:0;" onclick="return confirm('واردسازی با حالت انتخاب‌شده انجام شود؟');">تأیید و واردسازی</button>
    </div>
</form>
<?php endif; ?>

<?php $report = $previewReport ?: (json_decode((string) ($import['report_json'] ?? ''), true) ?: []); ?>
<?php if ($report): ?>
<div class="admin-card">
    <h3 style="color:#031D4F;">خلاصه<?= $previewReport ? ' پیش‌نمایش' : '' ?></h3>
    <div class="stat-grid">
        <div class="stat-card"><h3><?= (int) ($report['total'] ?? 0) ?></h3><p>کل رکوردها</p></div>
        <div class="stat-card"><h3><?= (int) ($report['duplicates'] ?? 0) ?></h3><p>بیماران موجود</p></div>
        <div class="stat-card"><h3><?= (int) ($report['imported'] ?? 0) ?></h3><p>بیماران جدید</p></div>
        <div class="stat-card"><h3><?= (int) ($report['conflicts'] ?? 0) ?></h3><p>نیازمند بررسی</p></div>
        <div class="stat-card"><h3><?= (int) ($report['invalid'] ?? 0) ?></h3><p>نامعتبر</p></div>
    </div>
    <?php if (!empty($report['new_preview'])): ?>
        <h4>نمونه بیماران جدید</h4>
        <pre class="sms-preview"><?= e(json_encode($report['new_preview'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) ?></pre>
    <?php endif; ?>
    <?php if (!empty($report['conflict_preview'])): ?>
        <h4>نمونه تعارض‌ها</h4>
        <pre class="sms-preview"><?= e(json_encode($report['conflict_preview'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) ?></pre>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if ($conflicts): ?>
<div class="admin-card">
    <h3 style="color:#031D4F;">ردیف‌های نیازمند بررسی</h3>
    <table class="admin-table">
        <thead><tr><th>#ردیف</th><th>نوع</th><th>بیمار موجود</th><th>وضعیت</th></tr></thead>
        <tbody>
        <?php foreach ($conflicts as $c): ?>
            <tr>
                <td><?= (int) $c['row_number'] ?></td>
                <td><?= e($c['match_type'] ?? '') ?></td>
                <td><?php if (!empty($c['existing_patient_id'])): ?><a href="<?= url('/admin/patients/' . (int) $c['existing_patient_id']) ?>">#<?= (int) $c['existing_patient_id'] ?></a><?php else: ?>—<?php endif; ?></td>
                <td><?= e($c['status'] ?? '') ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<p><a href="<?= url('/admin/imports') ?>">بازگشت به فهرست ورودها</a></p>
