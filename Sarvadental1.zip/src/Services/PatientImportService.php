<?php

declare(strict_types=1);

namespace Sarva\Services;

use PDO;
use PhpOffice\PhpSpreadsheet\IOFactory;

/**
 * Safe Excel patient importer.
 * Default mode: add_new only — never overwrite existing patients.
 *
 * Identity priority: file_number → national_id → normalized mobile.
 * Never match by name alone.
 */
final class PatientImportService
{
    public const MODE_ADD_NEW = 'add_new';
    public const MODE_REVIEW_CHANGES = 'review_changes';
    public const MODE_UPDATE = 'update_existing';

    public function __construct(private readonly PDO $db)
    {
    }

    /** @return array{ok:bool, sheets?:array, message?:string, previous_imports?:list<array>} */
    public function inspect(string $absolutePath): array
    {
        if (!is_file($absolutePath)) {
            return ['ok' => false, 'message' => 'فایل یافت نشد.'];
        }
        $hash = hash_file('sha256', $absolutePath) ?: null;
        $previous = [];
        if ($hash) {
            $st = $this->db->prepare(
                'SELECT id, original_name, filename, status, created_at, imported_rows, duplicate_rows, invalid_rows, conflict_rows, total_rows
                 FROM excel_imports WHERE file_hash=? ORDER BY id DESC LIMIT 5'
            );
            $st->execute([$hash]);
            $previous = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
        }

        $spreadsheet = IOFactory::load($absolutePath);
        $sheets = [];
        foreach ($spreadsheet->getAllSheets() as $idx => $sheet) {
            $rows = $sheet->toArray(null, true, true, true);
            $header = $rows[1] ?? [];
            $sample = [];
            $i = 0;
            foreach ($rows as $rIdx => $row) {
                if ((int) $rIdx === 1) {
                    continue;
                }
                if ($this->rowEmpty($row)) {
                    continue;
                }
                $sample[] = $row;
                if (++$i >= 5) {
                    break;
                }
            }
            $sheets[] = [
                'index' => $idx,
                'title' => $sheet->getTitle(),
                'columns' => $header,
                'letters' => array_keys($header),
                'sample' => $sample,
                'row_count' => max(0, count($rows) - 1),
                'guess' => $this->guessMapping($header),
                'is_patient_sheet' => $this->isPatientSheet($sheet->getTitle(), $header),
            ];
        }
        return ['ok' => true, 'sheets' => $sheets, 'file_hash' => $hash, 'previous_imports' => $previous];
    }

    /**
     * @param array<string, mixed> $header
     * @return array<string, string>
     */
    public function guessMapping(array $header): array
    {
        $map = [];
        foreach ($header as $letter => $label) {
            $n = mb_strtolower(trim((string) $label));
            $letter = (string) $letter;
            if ($n === '') {
                continue;
            }
            if (preg_match('/پرونده|file|patient.?no|کد پرونده/', $n)) {
                $map['file_number'] = $letter;
            } elseif (preg_match('/تلفن همراه|موبایل|mobile|همراه/', $n)) {
                $map['mobile'] = $letter;
            } elseif (preg_match('/تلفن ثابت|ثابت|landline|home.?phone/', $n)) {
                $map['landline'] = $letter;
            } elseif (preg_match('/نام خانواد|last.?name|فامیل/', $n)) {
                $map['last_name'] = $letter;
            } elseif (preg_match('/نام پدر|father/', $n)) {
                $map['father_name'] = $letter;
            } elseif (preg_match('/^نام$|first.?name/', $n) && !isset($map['first_name'])) {
                $map['first_name'] = $letter;
            } elseif (preg_match('/سال تولد|birth.?year/', $n)) {
                $map['birth_year_jalali'] = $letter;
            } elseif (preg_match('/تاریخ تولد|birth.?date|تولد/', $n) && !isset($map['birth_year_jalali'])) {
                $map['birth_date'] = $letter;
            } elseif (preg_match('/کد ملی|national|meli/', $n)) {
                $map['national_id'] = $letter;
            } elseif (preg_match('/ایمیل|email/', $n)) {
                $map['email'] = $letter;
            } elseif (preg_match('/آدرس|address/', $n)) {
                $map['address'] = $letter;
            } elseif (preg_match('/معرف|referr/', $n)) {
                $map['referrer'] = $letter;
            } elseif (preg_match('/جنسیت|gender/', $n)) {
                $map['gender'] = $letter;
            }
        }
        return $map;
    }

    /** Default mapping for Sarva «پرونده» sheet. */
    public function sarvaParvandehMapping(): array
    {
        return [
            'file_number' => 'A',
            'first_name' => 'B',
            'last_name' => 'C',
            'father_name' => 'D',
            'birth_year_jalali' => 'E',
            'mobile' => 'F',
            'landline' => 'G',
            'referrer' => 'H',
        ];
    }

    /**
     * @param array<string, string> $mapping
     * @return array{ok:bool, report:array}
     */
    public function preview(string $absolutePath, int $sheetIndex, array $mapping, string $mode = self::MODE_ADD_NEW): array
    {
        return $this->run($absolutePath, $sheetIndex, $mapping, $mode, 0, true);
    }

    /**
     * @param array<string, string> $mapping
     * @return array{ok:bool, report:array}
     */
    public function import(int $importId, string $absolutePath, int $sheetIndex, array $mapping, string $mode = self::MODE_ADD_NEW): array
    {
        if (!in_array($mode, [self::MODE_ADD_NEW, self::MODE_REVIEW_CHANGES, self::MODE_UPDATE], true)) {
            $mode = self::MODE_ADD_NEW;
        }
        return $this->run($absolutePath, $sheetIndex, $mapping, $mode, $importId, false);
    }

    /**
     * Import radiography index rows as document stubs (optional second pass).
     * Links by unique full-name match only; otherwise stores unlinked.
     */
    public function importRadiographySheet(int $importId, string $absolutePath): array
    {
        $spreadsheet = IOFactory::load($absolutePath);
        $sheet = null;
        foreach ($spreadsheet->getAllSheets() as $s) {
            if (str_contains($s->getTitle(), 'رادیو')) {
                $sheet = $s;
                break;
            }
        }
        if (!$sheet) {
            return ['ok' => false, 'message' => 'برگه رادیوگرافی یافت نشد.', 'linked' => 0, 'unlinked' => 0];
        }
        $rows = $sheet->toArray(null, true, true, true);
        $linked = 0;
        $unlinked = 0;
        $ins = $this->db->prepare(
            'INSERT INTO patient_documents
             (patient_id, category, title, description, file_path, original_name, document_date, source, import_id, external_ref, uploaded_by)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)'
        );
        foreach ($rows as $num => $row) {
            if ((int) $num === 1) {
                continue;
            }
            $photoNo = trim((string) ($row['T'] ?? ''));
            $last = normalize_persian_text(trim((string) ($row['U'] ?? '')));
            $first = normalize_persian_text(trim((string) ($row['V'] ?? '')));
            if ($photoNo === '' && $first === '' && $last === '') {
                continue;
            }
            $patientId = null;
            if ($first !== '' && $last !== '') {
                $patientId = $this->findUniqueByName($first, $last);
            }
            $title = 'رادیوگرافی #' . ($photoNo !== '' ? $photoNo : $num);
            $desc = trim($first . ' ' . $last);
            $ins->execute([
                $patientId,
                'radiography',
                $title,
                $desc !== '' ? $desc : null,
                'import://radiography/' . $photoNo,
                $title,
                null,
                'excel',
                $importId,
                $photoNo !== '' ? 'RAD-' . $photoNo : null,
                null,
            ]);
            if ($patientId) {
                $linked++;
            } else {
                $unlinked++;
            }
        }
        return ['ok' => true, 'linked' => $linked, 'unlinked' => $unlinked];
    }

    /**
     * @param array<string, string> $mapping
     * @return array{ok:bool, report:array}
     */
    private function run(string $absolutePath, int $sheetIndex, array $mapping, string $mode, int $importId, bool $dryRun): array
    {
        $spreadsheet = IOFactory::load($absolutePath);
        $sheet = $spreadsheet->getSheet($sheetIndex);
        $rows = $sheet->toArray(null, true, true, true);
        $worksheet = $sheet->getTitle();

        if ($mapping === []) {
            $mapping = $this->guessMapping($rows[1] ?? []);
            if ($this->isPatientSheet($worksheet, $rows[1] ?? [])) {
                $mapping = array_merge($this->sarvaParvandehMapping(), $mapping);
            }
        }

        $report = [
            'total' => 0,
            'imported' => 0,
            'updated' => 0,
            'duplicates' => 0,
            'skipped' => 0,
            'invalid' => 0,
            'conflicts' => 0,
            'new_preview' => [],
            'existing_preview' => [],
            'invalid_preview' => [],
            'conflict_preview' => [],
            'mode' => $mode,
            'worksheet' => $worksheet,
        ];

        $rowIns = null;
        $conflictIns = null;
        if (!$dryRun && $importId > 0) {
            $rowIns = $this->db->prepare(
                'INSERT INTO excel_import_rows (import_id, `row_number`, raw_json, status, message) VALUES (?,?,?,?,?)'
            );
            $conflictIns = $this->db->prepare(
                'INSERT INTO excel_import_conflicts (import_id, row_number, match_type, existing_patient_id, excel_json, existing_json, status)
                 VALUES (?,?,?,?,?,?,?)'
            );
            $this->db->prepare('UPDATE excel_imports SET worksheet_name=?, import_mode=?, status=? WHERE id=?')
                ->execute([$worksheet, $mode, 'previewed', $importId]);
        }

        foreach ($rows as $num => $row) {
            if ((int) $num === 1) {
                continue;
            }
            if ($this->rowEmpty($row)) {
                continue;
            }
            $report['total']++;

            $parsed = $this->parseRow($row, $mapping);
            $rawJson = json_encode($row, JSON_UNESCAPED_UNICODE);

            if ($parsed['file_number'] === null && $parsed['mobile'] === null && $parsed['national_id'] === null
                && $parsed['first_name'] === '' && $parsed['last_name'] === '') {
                $report['skipped']++;
                $rowIns?->execute([$importId, $num, $rawJson, 'skipped', 'ردیف خالی']);
                continue;
            }

            // Require at least file number OR (name + something) — prefer file number
            if ($parsed['file_number'] === null && $parsed['mobile'] === null && $parsed['national_id'] === null) {
                // Allow insert with name only only if we have both names — but flag as weak identity
                if ($parsed['first_name'] === '' || $parsed['last_name'] === '') {
                    $report['invalid']++;
                    if (count($report['invalid_preview']) < 20) {
                        $report['invalid_preview'][] = ['row' => $num, 'reason' => 'شناسه کافی نیست', 'data' => $parsed];
                    }
                    $rowIns?->execute([$importId, $num, $rawJson, 'invalid', 'شناسه کافی (پرونده/موبایل/کدملی) نیست']);
                    continue;
                }
            }

            $match = $this->findExistingDetailed($parsed['mobile'], $parsed['file_number'], $parsed['national_id']);

            if ($match) {
                $existingId = (int) $match['id'];
                $diff = $this->diffFields($match, $parsed);

                // Ambiguous: file matches one patient, mobile matches another
                if (!empty($match['conflict'])) {
                    $report['conflicts']++;
                    if (count($report['conflict_preview']) < 20) {
                        $report['conflict_preview'][] = [
                            'row' => $num,
                            'reason' => $match['conflict'],
                            'excel' => $parsed,
                            'existing_id' => $existingId,
                        ];
                    }
                    if (!$dryRun) {
                        $rowIns?->execute([$importId, $num, $rawJson, 'conflict', $match['conflict']]);
                        $conflictIns?->execute([
                            $importId, $num, 'ambiguous', $existingId, $rawJson,
                            json_encode($match, JSON_UNESCAPED_UNICODE), 'pending',
                        ]);
                    }
                    continue;
                }

                if ($mode === self::MODE_ADD_NEW) {
                    $report['duplicates']++;
                    if (count($report['existing_preview']) < 15) {
                        $report['existing_preview'][] = ['row' => $num, 'patient_id' => $existingId, 'match' => $match['matched_by']];
                    }
                    $rowIns?->execute([$importId, $num, $rawJson, 'duplicate', 'موجود — بدون تغییر (' . $match['matched_by'] . ')']);
                    continue;
                }

                if ($mode === self::MODE_REVIEW_CHANGES) {
                    if ($diff) {
                        $report['conflicts']++;
                        if (count($report['conflict_preview']) < 25) {
                            $report['conflict_preview'][] = [
                                'row' => $num,
                                'patient_id' => $existingId,
                                'diff' => $diff,
                                'excel' => $parsed,
                            ];
                        }
                        if (!$dryRun) {
                            $rowIns?->execute([$importId, $num, $rawJson, 'conflict', 'تفاوت با پرونده موجود']);
                            $conflictIns?->execute([
                                $importId, $num, 'field_diff', $existingId, json_encode($parsed, JSON_UNESCAPED_UNICODE),
                                json_encode(['patient' => $match, 'diff' => $diff], JSON_UNESCAPED_UNICODE), 'pending',
                            ]);
                        }
                    } else {
                        $report['duplicates']++;
                        $rowIns?->execute([$importId, $num, $rawJson, 'duplicate', 'یکسان با پرونده موجود']);
                    }
                    continue;
                }

                // MODE_UPDATE — only with explicit mode
                if (!$dryRun) {
                    $this->updatePatient($existingId, $parsed);
                    $rowIns?->execute([$importId, $num, $rawJson, 'updated', 'به‌روزرسانی صریح']);
                }
                $report['updated']++;
                continue;
            }

            // New patient
            if ($parsed['first_name'] === '' && $parsed['gender'] === 'female') {
                // first name was title «خانم»
            }
            if ($parsed['first_name'] === '') {
                $parsed['first_name'] = 'نامشخص';
            }
            if ($parsed['last_name'] === '') {
                $parsed['last_name'] = 'نامشخص';
            }

            if (count($report['new_preview']) < 20) {
                $report['new_preview'][] = ['row' => $num, 'data' => $parsed];
            }

            if (!$dryRun) {
                $newId = $this->insertPatient($parsed, $importId, (int) $num, $worksheet);
                $rowIns?->execute([$importId, $num, $rawJson, 'imported', 'بیمار جدید #' . $newId]);
            }
            $report['imported']++;
        }

        if (!$dryRun && $importId > 0) {
            $this->db->prepare(
                'UPDATE excel_imports SET total_rows=?, imported_rows=?, updated_rows=?, duplicate_rows=?, skipped_rows=?, invalid_rows=?, conflict_rows=?, status=?, report_json=? WHERE id=?'
            )->execute([
                $report['total'],
                $report['imported'],
                $report['updated'],
                $report['duplicates'],
                $report['skipped'],
                $report['invalid'],
                $report['conflicts'],
                'completed',
                json_encode($report, JSON_UNESCAPED_UNICODE),
                $importId,
            ]);
            audit('patients.import_completed', 'excel_imports', $importId, [
                'imported' => $report['imported'],
                'duplicates' => $report['duplicates'],
                'mode' => $mode,
            ]);
        }

        return ['ok' => true, 'report' => $report];
    }

    /**
     * @param array<string, mixed> $row
     * @param array<string, string> $mapping
     * @return array<string, mixed>
     */
    private function parseRow(array $row, array $mapping): array
    {
        $get = function (string $field) use ($row, $mapping): string {
            if (empty($mapping[$field])) {
                return '';
            }
            return trim((string) ($row[$mapping[$field]] ?? ''));
        };

        $first = normalize_persian_text($get('first_name'));
        $last = normalize_persian_text($get('last_name'));
        $father = normalize_persian_text($get('father_name'));
        $gender = null;
        $firstNorm = preg_replace('/\s+/u', '', $first) ?? '';
        if ($firstNorm === 'خانم' || $firstNorm === 'خانوم') {
            $gender = 'female';
            $first = '';
        } elseif ($firstNorm === 'آقا' || $firstNorm === 'اقا' || $firstNorm === 'اقای' || $firstNorm === 'آقای') {
            $gender = 'male';
            $first = '';
        } elseif (preg_match('/^(آقا|اقا|آقای|اقای)[\s‌]/u', $first)) {
            $gender = 'male';
            $first = normalize_persian_text(preg_replace('/^(آقا|اقا|آقای|اقای)[\s‌]*/u', '', $first) ?? $first);
        }
        $gRaw = mb_strtolower($get('gender'));
        if (in_array($gRaw, ['female', 'زن', 'خانم'], true)) {
            $gender = 'female';
        } elseif (in_array($gRaw, ['male', 'مرد', 'آقا'], true)) {
            $gender = 'male';
        }

        $file = normalize_digits($get('file_number'));
        $file = $file !== '' ? ltrim($file, '0') ?: $file : null;
        // keep original numeric string without decimals
        if ($file !== null && str_contains($file, '.')) {
            $file = (string) (int) round((float) $file);
        }

        $mobile = normalize_mobile(normalize_digits($get('mobile')));
        $landline = normalize_digits($get('landline')) ?: null;
        if ($landline !== null) {
            $landline = mb_substr($landline, 0, 40);
        }
        $nid = normalize_digits($get('national_id')) ?: null;
        if ($nid !== null && !preg_match('/^\d{10}$/', $nid)) {
            $nid = null;
        }

        $by = normalize_digits($get('birth_year_jalali'));
        $birthYear = null;
        $birthDate = null;
        if ($by !== '' && ctype_digit($by)) {
            $y = (int) $by;
            if ($y >= 1 && $y <= 99) {
                $y += 1300; // Jalali short year → 13xx
            }
            if ($y >= 1270 && $y <= 1450) {
                $birthYear = $y;
                // Approximate Gregorian Jan 1 of corresponding year (rough)
                $gy = $y + 621;
                if (checkdate(3, 21, $gy) || checkdate(1, 1, $gy)) {
                    $birthDate = sprintf('%04d-01-01', $gy);
                }
            }
        }
        $bdRaw = $get('birth_date');
        if ($bdRaw !== '') {
            $ts = strtotime(normalize_digits($bdRaw));
            if ($ts) {
                $birthDate = date('Y-m-d', $ts);
            }
        }

        return [
            'file_number' => $file,
            'first_name' => $first,
            'last_name' => $last,
            'father_name' => $father !== '' ? $father : null,
            'mobile' => $mobile,
            'landline' => $landline,
            'national_id' => $nid,
            'email' => $get('email') ?: null,
            'address' => $get('address') ?: null,
            'referrer' => $get('referrer') !== '' ? mb_substr($get('referrer'), 0, 190) : null,
            'gender' => $gender,
            'birth_year_jalali' => $birthYear,
            'birth_date' => $birthDate,
        ];
    }

    /**
     * @return array<string, mixed>|null
     */
    private function findExistingDetailed(?string $mobile, ?string $file, ?string $nid): ?array
    {
        $byFile = null;
        $byMobile = null;
        $byNid = null;

        if ($file) {
            $st = $this->db->prepare('SELECT * FROM patients WHERE file_number=? AND deleted_at IS NULL LIMIT 2');
            $st->execute([$file]);
            $rows = $st->fetchAll(PDO::FETCH_ASSOC);
            if (count($rows) > 1) {
                return ['id' => (int) $rows[0]['id'], 'matched_by' => 'file_number', 'conflict' => 'چند بیمار با یک شماره پرونده', 'rows' => $rows] + $rows[0];
            }
            if ($rows) {
                $byFile = $rows[0];
            }
        }
        if ($nid) {
            $st = $this->db->prepare('SELECT * FROM patients WHERE national_id=? AND deleted_at IS NULL LIMIT 1');
            $st->execute([$nid]);
            $byNid = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        }
        if ($mobile) {
            $st = $this->db->prepare('SELECT * FROM patients WHERE mobile=? AND deleted_at IS NULL LIMIT 1');
            $st->execute([$mobile]);
            $byMobile = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        }

        // Prefer file number
        if ($byFile) {
            if ($byMobile && (int) $byMobile['id'] !== (int) $byFile['id']) {
                return $byFile + ['id' => (int) $byFile['id'], 'matched_by' => 'file_number', 'conflict' => 'شماره پرونده و موبایل به دو بیمار متفاوت اشاره دارند'];
            }
            return $byFile + ['id' => (int) $byFile['id'], 'matched_by' => 'file_number', 'conflict' => null];
        }
        if ($byNid) {
            if ($byMobile && (int) $byMobile['id'] !== (int) $byNid['id']) {
                return $byNid + ['id' => (int) $byNid['id'], 'matched_by' => 'national_id', 'conflict' => 'کد ملی و موبایل ناسازگارند'];
            }
            return $byNid + ['id' => (int) $byNid['id'], 'matched_by' => 'national_id', 'conflict' => null];
        }
        if ($byMobile) {
            return $byMobile + ['id' => (int) $byMobile['id'], 'matched_by' => 'mobile', 'conflict' => null];
        }
        return null;
    }

    /** @param array<string, mixed> $existing @param array<string, mixed> $parsed */
    private function diffFields(array $existing, array $parsed): array
    {
        $diff = [];
        foreach (['first_name', 'last_name', 'father_name', 'mobile', 'landline', 'referrer', 'national_id'] as $k) {
            $a = trim((string) ($existing[$k] ?? ''));
            $b = trim((string) ($parsed[$k] ?? ''));
            if ($b !== '' && $a !== '' && $a !== $b) {
                $diff[$k] = ['existing' => $a, 'excel' => $b];
            }
        }
        return $diff;
    }

    /** @param array<string, mixed> $p */
    private function insertPatient(array $p, int $importId, int $rowNum, string $worksheet): int
    {
        $code = 'P' . strtoupper(bin2hex(random_bytes(4)));
        // Avoid unique collisions on file_number
        $file = $p['file_number'];
        if ($file) {
            $chk = $this->db->prepare('SELECT id FROM patients WHERE file_number=? LIMIT 1');
            $chk->execute([$file]);
            if ($chk->fetchColumn()) {
                $file = $file . '-R' . $rowNum;
            }
        }
        $this->db->prepare(
            'INSERT INTO patients
             (public_code, file_number, first_name, last_name, father_name, mobile, landline, national_id,
              birth_date, birth_year_jalali, gender, email, address, referrer,
              is_imported, import_id, import_row_number, import_worksheet, profile_completed, is_active)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,0,1)'
        )->execute([
            $code,
            $file,
            $p['first_name'],
            $p['last_name'],
            $p['father_name'],
            $p['mobile'],
            $p['landline'],
            $p['national_id'],
            $p['birth_date'],
            $p['birth_year_jalali'],
            $p['gender'],
            $p['email'],
            $p['address'],
            $p['referrer'],
            $importId > 0 ? $importId : null,
            $rowNum,
            $worksheet,
        ]);
        return (int) $this->db->lastInsertId();
    }

    /** @param array<string, mixed> $p */
    private function updatePatient(int $id, array $p): void
    {
        $this->db->prepare(
            'UPDATE patients SET
                first_name=COALESCE(NULLIF(?, ""), first_name),
                last_name=COALESCE(NULLIF(?, ""), last_name),
                father_name=COALESCE(?, father_name),
                mobile=COALESCE(?, mobile),
                landline=COALESCE(?, landline),
                national_id=COALESCE(?, national_id),
                birth_year_jalali=COALESCE(?, birth_year_jalali),
                birth_date=COALESCE(?, birth_date),
                gender=COALESCE(?, gender),
                referrer=COALESCE(?, referrer),
                email=COALESCE(NULLIF(?, ""), email),
                address=COALESCE(NULLIF(?, ""), address),
                is_imported=1
             WHERE id=?'
        )->execute([
            $p['first_name'], $p['last_name'], $p['father_name'], $p['mobile'], $p['landline'],
            $p['national_id'], $p['birth_year_jalali'], $p['birth_date'], $p['gender'], $p['referrer'],
            (string) ($p['email'] ?? ''), (string) ($p['address'] ?? ''), $id,
        ]);
    }

    private function findUniqueByName(string $first, string $last): ?int
    {
        $st = $this->db->prepare(
            'SELECT id FROM patients WHERE first_name=? AND last_name=? AND deleted_at IS NULL LIMIT 2'
        );
        $st->execute([$first, $last]);
        $ids = $st->fetchAll(PDO::FETCH_COLUMN);
        return count($ids) === 1 ? (int) $ids[0] : null;
    }

    /** @param array<string, mixed> $header */
    private function isPatientSheet(string $title, array $header): bool
    {
        if (str_contains($title, 'پرونده')) {
            return true;
        }
        $joined = implode(' ', array_map('strval', $header));
        return str_contains($joined, 'شماره پرونده') && str_contains($joined, 'نام');
    }

    /** @param array<string, mixed> $row */
    private function rowEmpty(array $row): bool
    {
        foreach ($row as $v) {
            if (trim((string) $v) !== '') {
                return false;
            }
        }
        return true;
    }
}
