<?php

declare(strict_types=1);

namespace Sarva\Services;

use PDO;

final class SmsAutomationService
{
    public function __construct(private readonly PDO $db, private readonly SmsService $sms)
    {
    }

    public function enqueueDue(int $lookAheadHours = 48): int
    {
        if (!$this->sms->isEnabled()) {
            return 0;
        }
        $tz = (string) setting('timezone', config('app.timezone', 'Asia/Tehran'));
        if ($tz !== '') {
            date_default_timezone_set($tz);
        }

        $rules = $this->db->query(
            "SELECT r.*, t.body AS template_body, t.slug AS template_slug
             FROM sms_automation_rules r
             JOIN sms_templates t ON t.id = r.template_id AND t.is_active=1 AND t.deleted_at IS NULL
             WHERE r.is_active=1 AND r.trigger_type='appointment'"
        )->fetchAll(PDO::FETCH_ASSOC);

        $queued = 0;
        foreach ($rules as $rule) {
            $queued += $this->enqueueRule($rule);
        }
        return $queued;
    }

    /** @param array<string, mixed> $rule */
    private function enqueueRule(array $rule): int
    {
        $statuses = array_filter(array_map('trim', explode(',', (string) ($rule['appointment_statuses'] ?: 'confirmed'))));
        if ($statuses === []) {
            $statuses = ['confirmed'];
        }
        $placeholders = implode(',', array_fill(0, count($statuses), '?'));
        $params = $statuses;
        $extra = '';
        if (!empty($rule['doctor_id'])) {
            $extra .= ' AND a.doctor_id = ?';
            $params[] = (int) $rule['doctor_id'];
        }
        if (!empty($rule['service_id'])) {
            $extra .= ' AND a.service_id = ?';
            $params[] = (int) $rule['service_id'];
        }

        $unit = $rule['offset_unit'] === 'hours' ? 'hours' : 'days';
        $offset = max(1, (int) $rule['offset_value']);

        if ($unit === 'days') {
            $sql = "SELECT a.id, a.starts_at, a.patient_id, p.mobile, p.first_name, p.last_name, p.file_number, p.public_code,
                           CONCAT(d.first_name,' ',d.last_name) doctor_name, s.name service_name
                    FROM appointments a
                    JOIN patients p ON p.id=a.patient_id AND p.deleted_at IS NULL
                    JOIN doctors d ON d.id=a.doctor_id
                    JOIN services s ON s.id=a.service_id
                    WHERE a.deleted_at IS NULL
                      AND a.status IN ($placeholders)
                      $extra
                      AND DATE(a.starts_at) = DATE(DATE_ADD(NOW(), INTERVAL {$offset} DAY))";
            $sendTime = substr((string) ($rule['send_time'] ?: '18:00:00'), 0, 8);
            if ($sendTime !== '' && date('H:i:s') < $sendTime) {
                return 0;
            }
        } else {
            $sql = "SELECT a.id, a.starts_at, a.patient_id, p.mobile, p.first_name, p.last_name, p.file_number, p.public_code,
                           CONCAT(d.first_name,' ',d.last_name) doctor_name, s.name service_name
                    FROM appointments a
                    JOIN patients p ON p.id=a.patient_id AND p.deleted_at IS NULL
                    JOIN doctors d ON d.id=a.doctor_id
                    JOIN services s ON s.id=a.service_id
                    WHERE a.deleted_at IS NULL
                      AND a.status IN ($placeholders)
                      $extra
                      AND a.starts_at > NOW()
                      AND a.starts_at <= DATE_ADD(NOW(), INTERVAL {$offset} HOUR)";
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $count = 0;
        $type = 'appointment_reminder';
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $key = 'auto:' . (int) $rule['id'] . ':' . (int) $row['id'] . ':' . $type;
            $message = SmsTemplateRenderer::render((string) $rule['template_body'], SmsTemplateRenderer::varsFrom($row, $row));
            $id = $this->sms->enqueue([
                'patient_id' => (int) $row['patient_id'],
                'appointment_id' => (int) $row['id'],
                'template_id' => (int) $rule['template_id'],
                'automation_rule_id' => (int) $rule['id'],
                'mobile' => (string) $row['mobile'],
                'message' => $message,
                'message_type' => $type,
                'source' => 'automation',
                'idempotency_key' => $key,
                'appointment_starts_at' => $row['starts_at'],
            ]);
            if ($id > 0) {
                $count++;
            }
        }
        $this->db->prepare('UPDATE sms_automation_rules SET last_enqueued_at=NOW() WHERE id=?')->execute([(int) $rule['id']]);
        return $count;
    }

    /** @return array{send_at:string, appointment_at:string, preview:string} */
    public function preview(array $rule, ?array $template = null): array
    {
        $tz = (string) setting('timezone', 'Asia/Tehran');
        $now = new \DateTimeImmutable('now', new \DateTimeZone($tz));
        $unit = ($rule['offset_unit'] ?? 'days') === 'hours' ? 'hours' : 'days';
        $offset = max(1, (int) ($rule['offset_value'] ?? 1));
        $sampleAppt = $now->modify('+1 day')->setTime(10, 30);
        if ($unit === 'days') {
            $send = $sampleAppt->modify("-{$offset} days");
            $st = (string) ($rule['send_time'] ?? '18:00:00');
            [$h, $m] = array_map('intval', explode(':', $st . ':00'));
            $send = $send->setTime($h ?: 18, $m);
        } else {
            $send = $sampleAppt->modify("-{$offset} hours");
        }
        $body = (string) ($template['body'] ?? 'سلام {full_name}\nیادآوری نوبت: {appointment_time}');
        $preview = SmsTemplateRenderer::render($body, [
            'full_name' => 'علی رضایی',
            'first_name' => 'علی',
            'last_name' => 'رضایی',
            'patient_number' => 'P1001',
            'appointment_date' => to_jalali($sampleAppt->format('Y-m-d H:i:s'), 'Y/m/d'),
            'appointment_time' => $sampleAppt->format('H:i'),
            'doctor_name' => 'دکتر نمونه',
            'service_name' => 'ویزیت',
            'clinic_name' => (string) setting('clinic_name', 'کلینیک دندانپزشکی سروا'),
            'clinic_phone' => (string) setting('phone', ''),
        ]);
        return [
            'appointment_at' => to_jalali($sampleAppt->format('Y-m-d H:i:s'), 'Y/m/d H:i'),
            'send_at' => to_jalali($send->format('Y-m-d H:i:s'), 'Y/m/d H:i'),
            'preview' => $preview,
        ];
    }
}
